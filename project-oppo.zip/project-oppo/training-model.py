# ==========================================
# YOLOv8 Bubble/Spot Detection with Class Imbalance Handling
# Complete Training Pipeline for Google Colab
# ==========================================

# ==========================================
# 1. SETUP & INSTALLATION
# ==========================================

# !pip install ultralytics roboflow opencv-python-headless matplotlib seaborn
# !pip install albumentations pillow scikit-learn imblearn

import os
import cv2
import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import shutil
import yaml
from collections import Counter, defaultdict
import random
from PIL import Image, ImageEnhance
import albumentations as A
from ultralytics import YOLO
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.utils.class_weight import compute_class_weight
from sklearn.model_selection import StratifiedShuffleSplit
import warnings
warnings.filterwarnings('ignore')

# Check GPU
print(f"CUDA available: {torch.cuda.is_available()}")
print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")

# ==========================================
# 2. DATA STRUCTURE SETUP
# ==========================================

# Define paths
DATA_ROOT = "/content/data"
IMAGES_PATH = f"{DATA_ROOT}/images"
LABELS_PATH = f"{DATA_ROOT}/labels"
CLASSES_FILE = f"{DATA_ROOT}/classes.txt"
NOTES_FILE = f"{DATA_ROOT}/notes.json"

# Create directories if they don't exist
os.makedirs(DATA_ROOT, exist_ok=True)
os.makedirs(IMAGES_PATH, exist_ok=True)
os.makedirs(LABELS_PATH, exist_ok=True)

print("Data structure:")
print(f"├── {DATA_ROOT}/")
print(f"│   ├── images/")
print(f"│   ├── labels/")
print(f"│   ├── classes.txt")
print(f"│   └── notes.json")

# Global variables for class imbalance handling
class_weights = {}
class_distribution = {}
minority_classes = []
majority_classes = []
imbalance_ratio = {}

# ==========================================
# 3. CLASS IMBALANCE ANALYSIS FUNCTIONS
# ==========================================

def analyze_class_imbalance():
    """Analyze class distribution and identify imbalances"""
    global class_weights, class_distribution, minority_classes, majority_classes, imbalance_ratio
    
    print("🔍 Analyzing class distribution and imbalance...")
    
    classes = load_classes(CLASSES_FILE)
    class_counts = defaultdict(int)
    total_annotations = 0
    
    # Count annotations per class
    label_files = [f for f in os.listdir(LABELS_PATH) if f.endswith('.txt')]
    
    for label_file in label_files:
        label_path = os.path.join(LABELS_PATH, label_file)
        
        try:
            with open(label_path, 'r') as f:
                lines = f.readlines()
            
            for line in lines:
                parts = line.strip().split()
                if len(parts) >= 5:
                    class_id = int(parts[0])
                    if class_id < len(classes):
                        class_counts[class_id] += 1
                        total_annotations += 1
        
        except Exception as e:
            print(f"Error reading {label_file}: {e}")
    
    if total_annotations == 0:
        print("⚠️ No annotations found!")
        return False
    
    # Calculate distribution and imbalance ratios
    class_distribution = {}
    for class_id in range(len(classes)):
        count = class_counts[class_id]
        class_distribution[classes[class_id]] = {
            'count': count,
            'percentage': (count / total_annotations) * 100 if total_annotations > 0 else 0,
            'class_id': class_id
        }
    
    # Find majority and minority classes
    counts = [class_counts[i] for i in range(len(classes))]
    max_count = max(counts) if counts else 1
    min_count = min([c for c in counts if c > 0]) if counts else 1
    
    # Define imbalance threshold (if ratio > 3:1, consider imbalanced)
    imbalance_threshold = 3.0
    
    for class_id, class_name in enumerate(classes):
        count = class_counts[class_id]
        if count > 0:
            ratio = max_count / count
            imbalance_ratio[class_name] = ratio
            
            if ratio > imbalance_threshold:
                minority_classes.append(class_name)
            else:
                majority_classes.append(class_name)
    
    # Calculate class weights using sklearn's method
    class_ids = []
    for label_file in label_files:
        label_path = os.path.join(LABELS_PATH, label_file)
        try:
            with open(label_path, 'r') as f:
                lines = f.readlines()
            for line in lines:
                parts = line.strip().split()
                if len(parts) >= 5:
                    class_id = int(parts[0])
                    if class_id < len(classes):
                        class_ids.append(class_id)
        except:
            continue
    
    if class_ids:
        unique_classes = np.unique(class_ids)
        weights = compute_class_weight('balanced', classes=unique_classes, y=class_ids)
        
        # Create class weight dictionary
        for i, class_id in enumerate(unique_classes):
            if class_id < len(classes):
                class_weights[classes[class_id]] = weights[i]
    
    # Print analysis results
    print("\n📊 CLASS DISTRIBUTION ANALYSIS:")
    print("-" * 50)
    for class_name, info in class_distribution.items():
        count = info['count']
        percentage = info['percentage']
        ratio = imbalance_ratio.get(class_name, 1.0)
        status = "MINORITY" if class_name in minority_classes else "MAJORITY"
        
        print(f"{class_name:15} | Count: {count:6d} | {percentage:5.1f}% | Ratio: 1:{ratio:.1f} | {status}")
    
    print(f"\nTotal annotations: {total_annotations}")
    print(f"Imbalanced classes: {len(minority_classes)}")
    print(f"Balanced classes: {len(majority_classes)}")
    
    if minority_classes:
        print(f"\n⚠️  IMBALANCE DETECTED!")
        print(f"Minority classes: {minority_classes}")
        print(f"Will apply class balancing techniques...")
    else:
        print(f"\n✅ Classes are relatively balanced")
    
    return True

def calculate_focal_loss_params():
    """Calculate optimal focal loss parameters based on class distribution"""
    if not minority_classes:
        return 1.0, 2.0  # Default alpha and gamma
    
    # Calculate alpha (class balancing factor)
    max_ratio = max(imbalance_ratio.values()) if imbalance_ratio else 1.0
    alpha = min(max_ratio / 10.0, 1.0)  # Scale alpha based on imbalance
    
    # Calculate gamma (focusing parameter)
    gamma = 2.0 + (max_ratio - 1.0) * 0.1  # Increase gamma for higher imbalance
    gamma = min(gamma, 5.0)  # Cap gamma at 5.0
    
    print(f"📊 Focal Loss Parameters: alpha={alpha:.2f}, gamma={gamma:.2f}")
    return alpha, gamma

# ==========================================
# 4. HELPER FUNCTIONS
# ==========================================

def load_classes(classes_file):
    """Load class names from classes.txt"""
    try:
        with open(classes_file, 'r') as f:
            classes = [line.strip() for line in f.readlines() if line.strip()]
        return classes
    except FileNotFoundError:
        print(f"Warning: {classes_file} not found. Creating default classes.")
        default_classes = ["bubble", "spot", "defect"]
        with open(classes_file, 'w') as f:
            for cls in default_classes:
                f.write(f"{cls}\n")
        return default_classes

def load_notes(notes_file):
    """Load notes from notes.json"""
    try:
        with open(notes_file, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Warning: {notes_file} not found. Creating empty notes.")
        default_notes = {
            "project_name": "Bubble Detection with Class Balancing",
            "description": "Deteksi gelembung/bintik pada layar HP dengan penanganan class imbalance",
            "image_format": "jpg/png",
            "annotation_format": "YOLO",
            "classes": load_classes(CLASSES_FILE)
        }
        with open(notes_file, 'w') as f:
            json.dump(default_notes, f, indent=2)
        return default_notes

def enhance_grayscale_image(image_path, output_path):
    """Enhance grayscale image for better bubble detection"""
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    
    if img is None:
        return False
    
    # CLAHE (Contrast Limited Adaptive Histogram Equalization)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    enhanced = clahe.apply(img)
    
    # Bilateral filter to reduce noise while preserving edges
    filtered = cv2.bilateralFilter(enhanced, 9, 75, 75)
    
    # Gamma correction
    def adjust_gamma(image, gamma=1.2):
        invGamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** invGamma) * 255
                         for i in np.arange(0, 256)]).astype("uint8")
        return cv2.LUT(image, table)
    
    gamma_corrected = adjust_gamma(filtered)
    
    # Convert back to BGR for YOLO
    final_img = cv2.cvtColor(gamma_corrected, cv2.COLOR_GRAY2BGR)
    
    # Save enhanced image
    cv2.imwrite(output_path, final_img)
    return True

def validate_dataset():
    """Validate dataset structure and files"""
    print("Validating dataset...")
    
    if not os.path.exists(IMAGES_PATH):
        print(f"❌ Images directory not found: {IMAGES_PATH}")
        return False
    
    if not os.path.exists(LABELS_PATH):
        print(f"❌ Labels directory not found: {LABELS_PATH}")
        return False
    
    image_files = [f for f in os.listdir(IMAGES_PATH) 
                   if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    label_files = [f for f in os.listdir(LABELS_PATH) 
                   if f.lower().endswith('.txt')]
    
    print(f"📊 Found {len(image_files)} images and {len(label_files)} labels")
    
    if len(image_files) == 0:
        print("❌ No images found!")
        return False
    
    if len(label_files) == 0:
        print("❌ No labels found!")
        return False
    
    image_names = set([os.path.splitext(f)[0] for f in image_files])
    label_names = set([os.path.splitext(f)[0] for f in label_files])
    
    matched = image_names.intersection(label_names)
    print(f"✅ {len(matched)} matched image-label pairs")
    
    if len(matched) < 10:
        print("⚠️  Warning: Very few samples found. Need at least 10 for training.")
    
    return len(matched) > 0

def create_sample_data():
    """Create sample data with intentional class imbalance for testing"""
    print("Creating sample data with class imbalance for testing...")
    
    # Create sample classes.txt
    sample_classes = ["bubble", "spot", "defect"]
    with open(CLASSES_FILE, 'w') as f:
        for cls in sample_classes:
            f.write(f"{cls}\n")
    
    # Create sample notes.json
    sample_notes = {
        "project_name": "Phone Screen Defect Detection with Class Balancing",
        "description": "Detection with intentional class imbalance handling",
        "image_format": ["jpg", "png"],
        "annotation_format": "YOLO",
        "classes": sample_classes,
        "total_images": 0,
        "date_created": "2024-01-01",
        "notes": "Sample dataset with class imbalance"
    }
    
    with open(NOTES_FILE, 'w') as f:
        json.dump(sample_notes, f, indent=2)
    
    # Create multiple test images with imbalanced classes
    # Class distribution: bubble (many), spot (few), defect (very few)
    class_probabilities = [0.7, 0.25, 0.05]  # Intentional imbalance
    
    for img_idx in range(20):  # Create 20 sample images
        img = np.ones((480, 640, 3), dtype=np.uint8) * 240  # Light gray background
        annotations = []
        
        # Randomly add objects based on class probabilities
        num_objects = random.randint(1, 5)
        
        for obj_idx in range(num_objects):
            # Select class based on probability (creating imbalance)
            class_id = np.random.choice(3, p=class_probabilities)
            
            # Random position
            x = random.randint(20, 620)
            y = random.randint(20, 460)
            
            # Draw different shapes for different classes
            if class_id == 0:  # bubble - circle
                radius = random.randint(8, 15)
                cv2.circle(img, (x, y), radius, (200, 200, 200), -1)
                cv2.circle(img, (x, y), radius-2, (180, 180, 180), -1)
                w_norm = h_norm = (radius * 2) / min(640, 480)
            
            elif class_id == 1:  # spot - small circle
                radius = random.randint(3, 8)
                cv2.circle(img, (x, y), radius, (150, 150, 150), -1)
                w_norm = h_norm = (radius * 2) / min(640, 480)
            
            else:  # defect - rectangle
                w = random.randint(10, 20)
                h = random.randint(5, 15)
                cv2.rectangle(img, (x-w//2, y-h//2), (x+w//2, y+h//2), (100, 100, 100), -1)
                w_norm = w / 640
                h_norm = h / 480
            
            # Create YOLO annotation
            x_norm = x / 640
            y_norm = y / 480
            
            annotations.append(f"{class_id} {x_norm:.6f} {y_norm:.6f} {w_norm:.6f} {h_norm:.6f}")
        
        # Save sample image
        sample_img_path = os.path.join(IMAGES_PATH, f"sample_{img_idx:03d}.jpg")
        cv2.imwrite(sample_img_path, img)
        
        # Save sample annotation
        sample_label_path = os.path.join(LABELS_PATH, f"sample_{img_idx:03d}.txt")
        with open(sample_label_path, 'w') as f:
            for ann in annotations:
                f.write(ann + '\n')
    
    print("✅ Sample data with class imbalance created successfully!")
    print(f"   - Images: {IMAGES_PATH}/sample_*.jpg")
    print(f"   - Labels: {LABELS_PATH}/sample_*.txt")

# ==========================================
# 5. CLASS BALANCING TECHNIQUES
# ==========================================

def apply_oversampling_augmentation():
    """Apply augmentation-based oversampling for minority classes"""
    if not minority_classes:
        print("✅ No minority classes detected, skipping oversampling")
        return
    
    print("🔄 Applying oversampling through augmentation for minority classes...")
    
    # Get target count (majority class count)
    majority_count = max([class_distribution[cls]['count'] for cls in majority_classes]) if majority_classes else 1
    
    # Create augmentation pipeline
    transform = A.Compose([
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.Rotate(limit=15, p=0.5),
        A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.5),
        A.GaussianBlur(blur_limit=3, p=0.3),
        A.GaussNoise(var_limit=(10, 30), p=0.3),
    ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))
    
    # For each minority class, generate additional samples
    for minority_class in minority_classes:
        minority_info = class_distribution[minority_class]
        current_count = minority_info['count']
        target_count = int(majority_count * 0.7)  # Target 70% of majority class
        needed_samples = max(0, target_count - current_count)
        
        if needed_samples == 0:
            continue
        
        print(f"   Generating {needed_samples} additional samples for '{minority_class}'")
        
        # Find images containing this minority class
        minority_images = []
        label_files = [f for f in os.listdir(LABELS_PATH) if f.endswith('.txt')]
        
        for label_file in label_files:
            label_path = os.path.join(LABELS_PATH, label_file)
            img_file = os.path.splitext(label_file)[0]
            
            # Check supported image extensions
            img_path = None
            for ext in ['.jpg', '.jpeg', '.png']:
                potential_path = os.path.join(IMAGES_PATH, img_file + ext)
                if os.path.exists(potential_path):
                    img_path = potential_path
                    break
            
            if img_path is None:
                continue
            
            # Check if this image contains minority class
            try:
                with open(label_path, 'r') as f:
                    lines = f.readlines()
                
                contains_minority = False
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        class_id = int(parts[0])
                        if class_id == minority_info['class_id']:
                            contains_minority = True
                            break
                
                if contains_minority:
                    minority_images.append((img_path, label_path))
            
            except Exception as e:
                continue
        
        if not minority_images:
            continue
        
        # Generate augmented samples
        generated = 0
        attempts = 0
        max_attempts = needed_samples * 3
        
        while generated < needed_samples and attempts < max_attempts:
            attempts += 1
            
            # Select random source image
            src_img_path, src_label_path = random.choice(minority_images)
            
            try:
                # Load image
                image = cv2.imread(src_img_path)
                if image is None:
                    continue
                
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                
                # Load bboxes
                bboxes = []
                class_labels = []
                
                with open(src_label_path, 'r') as f:
                    lines = f.readlines()
                
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        class_id = int(parts[0])
                        x, y, w, h = map(float, parts[1:5])
                        bboxes.append([x, y, w, h])
                        class_labels.append(class_id)
                
                if not bboxes:
                    continue
                
                # Apply augmentation
                augmented = transform(image=image, bboxes=bboxes, class_labels=class_labels)
                
                aug_image = augmented['image']
                aug_bboxes = augmented['bboxes']
                aug_labels = augmented['class_labels']
                
                if len(aug_bboxes) == 0:
                    continue
                
                # Save augmented image
                aug_img_name = f"aug_{minority_class}_{generated:04d}.jpg"
                aug_img_path = os.path.join(IMAGES_PATH, aug_img_name)
                aug_image_bgr = cv2.cvtColor(aug_image, cv2.COLOR_RGB2BGR)
                cv2.imwrite(aug_img_path, aug_image_bgr)
                
                # Save augmented labels
                aug_label_name = f"aug_{minority_class}_{generated:04d}.txt"
                aug_label_path = os.path.join(LABELS_PATH, aug_label_name)
                
                with open(aug_label_path, 'w') as f:
                    for bbox, label in zip(aug_bboxes, aug_labels):
                        x, y, w, h = bbox
                        f.write(f"{label} {x:.6f} {y:.6f} {w:.6f} {h:.6f}\n")
                
                generated += 1
                
            except Exception as e:
                continue
        
        print(f"   Generated {generated} samples for '{minority_class}'")

def create_weighted_dataset_config():
    """Create dataset configuration with class weights"""
    classes = load_classes(CLASSES_FILE)
    
    # Calculate loss weights based on class distribution
    loss_weights = {}
    if class_weights:
        # Normalize weights so minimum weight is 1.0
        min_weight = min(class_weights.values())
        for class_name, weight in class_weights.items():
            loss_weights[class_name] = weight / min_weight
    
    config = {
        'path': '/content/dataset',
        'train': 'images/train',
        'val': 'images/val',
        'test': 'images/test',
        'nc': len(classes),
        'names': classes
    }
    
    # Add class weights to config for custom loss calculation
    if loss_weights:
        config['class_weights'] = loss_weights
        print(f"📊 Class weights: {loss_weights}")
    
    config_path = "/content/dataset.yaml"
    with open(config_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False)
    
    print(f"✅ YOLO config with class balancing created: {config_path}")
    return config_path

# ==========================================
# 6. STRATIFIED DATA SPLITTING
# ==========================================

def stratified_split_dataset(train_ratio=0.8, val_ratio=0.1, test_ratio=0.1):
    """Stratified split to maintain class distribution across splits"""
    print("Splitting dataset with stratified sampling...")
    
    # Get all valid image-label pairs
    image_files = [f for f in os.listdir(IMAGES_PATH) 
                   if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    
    valid_pairs = []
    image_labels = []  # For stratification
    
    for img_file in image_files:
        label_file = os.path.splitext(img_file)[0] + '.txt'
        label_path = os.path.join(LABELS_PATH, label_file)
        
        if os.path.exists(label_path):
            # Get dominant class for this image (for stratification)
            try:
                with open(label_path, 'r') as f:
                    lines = f.readlines()
                
                class_counts = defaultdict(int)
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        class_id = int(parts[0])
                        class_counts[class_id] += 1
                
                if class_counts:
                    # Use most frequent class as label for stratification
                    dominant_class = max(class_counts.items(), key=lambda x: x[1])[0]
                    valid_pairs.append(img_file)
                    image_labels.append(dominant_class)
            
            except Exception as e:
                continue
    
    if len(valid_pairs) < 3:
        print("❌ Not enough data for stratified split!")
        return False
    
    print(f"Found {len(valid_pairs)} valid pairs for stratified splitting")
    
    # Perform stratified split
    try:
        # First split: train vs (val + test)
        sss1 = StratifiedShuffleSplit(n_splits=1, test_size=(val_ratio + test_ratio), random_state=42)
        train_idx, temp_idx = next(sss1.split(valid_pairs, image_labels))
        
        # Second split: val vs test from remaining data
        temp_pairs = [valid_pairs[i] for i in temp_idx]
        temp_labels = [image_labels[i] for i in temp_idx]
        
        if len(temp_pairs) >= 2:
            test_ratio_adjusted = test_ratio / (val_ratio + test_ratio)
            sss2 = StratifiedShuffleSplit(n_splits=1, test_size=test_ratio_adjusted, random_state=42)
            val_idx, test_idx = next(sss2.split(temp_pairs, temp_labels))
            
            train_files = [valid_pairs[i] for i in train_idx]
            val_files = [temp_pairs[i] for i in val_idx]
            test_files = [temp_pairs[i] for i in test_idx]
        else:
            # If too few samples for second split, put all temp in val
            train_files = [valid_pairs[i] for i in train_idx]
            val_files = temp_pairs
            test_files = []
    
    except Exception as e:
        print(f"Stratified split failed: {e}")
        # Fallback to random split
        print("Falling back to random split...")
        random.shuffle(valid_pairs)
        
        n_total = len(valid_pairs)
        n_train = int(n_total * train_ratio)
        n_val = int(n_total * val_ratio)
        
        train_files = valid_pairs[:n_train]
        val_files = valid_pairs[n_train:n_train + n_val]
        test_files = valid_pairs[n_train + n_val:]
    
    print(f"Split: Train={len(train_files)}, Val={len(val_files)}, Test={len(test_files)}")
    
    # Create dataset directories and copy files
    dataset_root = "/content/dataset"
    splits = {
        'train': train_files,
        'val': val_files,
        'test': test_files
    }
    
    for split_name, files in splits.items():
        if not files:  # Skip empty splits
            continue
            
        split_img_dir = f"{dataset_root}/images/{split_name}"
        split_label_dir = f"{dataset_root}/labels/{split_name}"
        os.makedirs(split_img_dir, exist_ok=True)
        os.makedirs(split_label_dir, exist_ok=True)
        
        # Analyze split class distribution
        split_class_counts = defaultdict(int)
        
        for img_file in files:
            # Copy image
            src_img = os.path.join(IMAGES_PATH, img_file)
            dst_img = os.path.join(split_img_dir, img_file)
            shutil.copy2(src_img, dst_img)
            
            # Copy label and count classes
            label_file = os.path.splitext(img_file)[0] + '.txt'
            src_label = os.path.join(LABELS_PATH, label_file)
            dst_label = os.path.join(split_label_dir, label_file)
            
            if os.path.exists(src_label):
                shutil.copy2(src_label, dst_label)
                
                # Count classes in this split
                try:
                    with open(src_label, 'r') as f:
                        lines = f.readlines()
                    
                    for line in lines:
                        parts = line.strip().split()
                        if len(parts) >= 5:
                            class_id = int(parts[0])
                            split_class_counts[class_id] += 1
                except:
                    continue
        
        # Print split class distribution
        classes = load_classes(CLASSES_FILE)
        print(f"\n{split_name.upper()} split class distribution:")
        for class_id, count in split_class_counts.items():
            if class_id < len(classes):
                print(f"   {classes[class_id]}: {count}")
    
    print("✅ Stratified dataset split completed!")
    return True

# ==========================================
# 7. DATA PREPROCESSING
# ==========================================

def preprocess_images():
    """Preprocess images for better detection"""
    print("Preprocessing images...")
    
    processed_dir = f"{DATA_ROOT}/processed_images"
    os.makedirs(processed_dir, exist_ok=True)
    
    image_files = [f for f in os.listdir(IMAGES_PATH) 
                   if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    
    processed_count = 0
    
    for img_file in image_files:
        img_path = os.path.join(IMAGES_PATH, img_file)
        processed_path = os.path.join(processed_dir, img_file)
        
        if enhance_grayscale_image(img_path, processed_path):
            processed_count += 1
    
    print(f"✅ Preprocessed {processed_count} images")
    
    # Update images path to use processed images
    global IMAGES_PATH
    if processed_count > 0:
        IMAGES_PATH = processed_dir
        print(f"Updated images path to: {IMAGES_PATH}")

# ==========================================
# 8. TRAINING SETUP WITH CLASS BALANCING
# ==========================================

def setup_training_with_class_balancing():
    """Setup training parameters with class balancing techniques"""
    
    # Calculate focal loss parameters
    alpha, gamma = calculate_focal_loss_params()
    
    # Base training parameters optimized for small objects and class imbalance
    train_params = {
        'epochs': 400,  # More epochs for imbalanced data
        'patience': 80,  # More patience for convergence
        'batch': 16,
        'imgsz': 1280,  # Higher resolution for small objects
        'device': 'cuda' if torch.cuda.is_available() else 'cpu',
        'workers': 4,
        'project': '/content/runs',
        'name': 'bubble_detection_balanced',
        'exist_ok': True,
        'pretrained': True,
        'optimizer': 'AdamW',
        'lr0': 0.0008,  # Slightly lower learning rate for stability
        'lrf': 0.005,   # Lower final learning rate
        'momentum': 0.937,
        'weight_decay': 0.0008,  # Slightly higher weight decay
        'warmup_epochs': 5,  # More warmup epochs
        'warmup_momentum': 0.8,
        'warmup_bias_lr': 0.1,
        'box': 0.05,
        'cls': 0.3,  # Lower cls loss weight (will be adjusted by focal loss)
        'cls_pw': 1.0,
        'obj': 1.0,
        'obj_pw': 1.0,
        'iou_t': 0.15,  # Lower IoU threshold for small objects
        'anchor_t': 4.0,
        'fl_gamma': gamma,  # Focal loss gamma for class imbalance
        'hsv_h': 0.015,
        'hsv_s': 0.7,
        'hsv_v': 0.4,
        'degrees': 0.0,
        'translate': 0.1,
        'scale': 0.5,
        'shear': 0.0,
        'perspective': 0.0,
        'flipud': 0.5,  # Increased for minority class augmentation
        'fliplr': 0.5,
        'mosaic': 0.9,  # Higher mosaic for better mixing
        'mixup': 0.15,  # Increased mixup for class balancing
        'copy_paste': 0.2,  # Higher copy-paste for minority classes
        'save_period': 20,
        'cache': 'ram',
        'single_cls': False,
        'rect': False,
        'cos_lr': True,  # Cosine learning rate for better convergence
        'close_mosaic': 15,  # Close mosaic later for better training
        'resume': False,
        'amp': True,
        'fraction': 1.0,
        'profile': False,
        'freeze': None,
        'multi_scale': True,  # Multi-scale training for robustness
        'overlap_mask': True,
        'mask_ratio': 4,
        'dropout': 0.1,  # Add dropout for regularization
        'val': True,
        'plots': True,
        'save': True,
        'save_txt': False,
        'save_conf': False,
        'save_crop': False,
        'show_labels': True,
        'show_conf': True,
        'visualize': False,
        'augment': False,
        'agnostic_nms': False,
        'retina_masks': False,
        'half': False,
        'dnn': False,
        'vid_stride': 1
    }
    
    # Adjust parameters based on class imbalance severity
    if minority_classes:
        max_imbalance = max(imbalance_ratio.values()) if imbalance_ratio else 1.0
        
        if max_imbalance > 10:  # Severe imbalance
            print("🚨 Severe class imbalance detected! Applying aggressive balancing...")
            train_params.update({
                'epochs': 500,
                'patience': 100,
                'copy_paste': 0.3,
                'mixup': 0.2,
                'mosaic': 0.95,
                'lr0': 0.0005,  # Even lower learning rate
            })
        
        elif max_imbalance > 5:  # Moderate imbalance
            print("⚠️ Moderate class imbalance detected! Applying standard balancing...")
            train_params.update({
                'epochs': 450,
                'patience': 90,
                'copy_paste': 0.25,
                'mixup': 0.18,
            })
    
    print(f"\n🎯 Training Configuration (Class Balanced):")
    print(f"   Model: YOLOv8n with Focal Loss")
    print(f"   Image Size: {train_params['imgsz']}")
    print(f"   Batch Size: {train_params['batch']}")
    print(f"   Epochs: {train_params['epochs']}")
    print(f"   Focal Loss Alpha: {alpha:.3f}, Gamma: {gamma:.3f}")
    print(f"   Learning Rate: {train_params['lr0']}")
    print(f"   Copy-Paste Augmentation: {train_params['copy_paste']}")
    print(f"   Mixup: {train_params['mixup']}")
    
    return train_params

# ==========================================
# 9. CUSTOM LOSS FUNCTIONS FOR CLASS IMBALANCE
# ==========================================

class FocalLoss(nn.Module):
    """Focal Loss implementation for addressing class imbalance"""
    
    def __init__(self, alpha=1.0, gamma=2.0, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
    
    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss

def create_class_balanced_augmentation():
    """Create augmentation pipeline with special focus on minority classes"""
    
    # Standard augmentations
    standard_transform = A.Compose([
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.Rotate(limit=15, p=0.3),
        A.CLAHE(clip_limit=2.0, p=0.8),
        A.RandomBrightnessContrast(brightness_limit=0.2, contrast_limit=0.2, p=0.5),
        A.GaussianBlur(blur_limit=3, p=0.3),
        A.GaussNoise(var_limit=(10, 30), p=0.3),
    ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))
    
    # Heavy augmentations for minority classes
    heavy_transform = A.Compose([
        A.HorizontalFlip(p=0.7),
        A.VerticalFlip(p=0.7),
        A.RandomRotate90(p=0.7),
        A.Rotate(limit=25, p=0.5),
        A.CLAHE(clip_limit=3.0, p=0.9),
        A.RandomBrightnessContrast(brightness_limit=0.3, contrast_limit=0.3, p=0.7),
        A.GaussianBlur(blur_limit=5, p=0.4),
        A.MotionBlur(blur_limit=5, p=0.3),
        A.GaussNoise(var_limit=(10, 50), p=0.4),
        A.HueSaturationValue(hue_shift_limit=10, sat_shift_limit=20, val_shift_limit=20, p=0.4),
        A.RandomGamma(gamma_limit=(80, 120), p=0.3),
        A.RandomContrast(limit=0.3, p=0.3),
    ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))
    
    return standard_transform, heavy_transform

# ==========================================
# 10. ENHANCED VALIDATION METRICS
# ==========================================

def calculate_balanced_metrics(model, val_loader=None):
    """Calculate class-balanced evaluation metrics"""
    
    print("📊 Calculating balanced evaluation metrics...")
    
    # Per-class metrics
    classes = load_classes(CLASSES_FILE)
    per_class_metrics = {}
    
    for i, class_name in enumerate(classes):
        if class_name in class_distribution:
            class_info = class_distribution[class_name]
            per_class_metrics[class_name] = {
                'class_id': i,
                'sample_count': class_info['count'],
                'class_weight': class_weights.get(class_name, 1.0),
                'is_minority': class_name in minority_classes
            }
    
    return per_class_metrics

def create_evaluation_plots():
    """Create comprehensive evaluation plots including class balance analysis"""
    
    print("📊 Creating class balance evaluation plots...")
    
    # Class distribution plot
    plt.figure(figsize=(15, 5))
    
    # Subplot 1: Class distribution
    plt.subplot(1, 3, 1)
    classes = list(class_distribution.keys())
    counts = [class_distribution[cls]['count'] for cls in classes]
    colors = ['red' if cls in minority_classes else 'blue' for cls in classes]
    
    bars = plt.bar(classes, counts, color=colors, alpha=0.7)
    plt.title('Class Distribution')
    plt.ylabel('Sample Count')
    plt.xticks(rotation=45)
    
    # Add value labels on bars
    for bar, count in zip(bars, counts):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5, 
                str(count), ha='center', va='bottom')
    
    # Legend
    plt.legend(['Minority Class' if any(cls in minority_classes for cls in classes) else 'Majority Class'])
    
    # Subplot 2: Class weights
    plt.subplot(1, 3, 2)
    if class_weights:
        weights = [class_weights.get(cls, 1.0) for cls in classes]
        plt.bar(classes, weights, color='green', alpha=0.7)
        plt.title('Class Weights')
        plt.ylabel('Weight Value')
        plt.xticks(rotation=45)
        
        for i, weight in enumerate(weights):
            plt.text(i, weight + 0.01, f'{weight:.2f}', ha='center', va='bottom')
    
    # Subplot 3: Imbalance ratios
    plt.subplot(1, 3, 3)
    if imbalance_ratio:
        ratios = [imbalance_ratio.get(cls, 1.0) for cls in classes]
        colors = ['red' if ratio > 3 else 'blue' for ratio in ratios]
        plt.bar(classes, ratios, color=colors, alpha=0.7)
        plt.title('Imbalance Ratios (1:X)')
        plt.ylabel('Ratio')
        plt.xticks(rotation=45)
        plt.axhline(y=3, color='red', linestyle='--', alpha=0.5, label='Imbalance Threshold')
        plt.legend()
    
    plt.tight_layout()
    plt.savefig('/content/class_balance_analysis.png', dpi=300, bbox_inches='tight')
    plt.show()

# ==========================================
# 11. MAIN EXECUTION PIPELINE
# ==========================================

def main():
    """Main execution pipeline with class imbalance handling"""
    print("🚀 Starting YOLOv8 Bubble Detection with Class Imbalance Handling")
    print("=" * 80)
    
    # Step 1: Load configuration
    classes = load_classes(CLASSES_FILE)
    notes = load_notes(NOTES_FILE)
    print(f"📋 Project: {notes.get('project_name', 'Bubble Detection')}")
    print(f"📋 Classes: {classes}")
    
    # Step 2: Validate dataset
    if not validate_dataset():
        print("⚠️  No valid dataset found. Creating sample data with class imbalance...")
        create_sample_data()
        if not validate_dataset():
            print("❌ Failed to create/validate dataset!")
            return
    
    # Step 3: Analyze class imbalance
    if not analyze_class_imbalance():
        print("❌ Failed to analyze class distribution!")
        return
    
    # Step 4: Apply oversampling for minority classes
    apply_oversampling_augmentation()
    
    # Step 5: Re-analyze after oversampling
    print("\n🔄 Re-analyzing class distribution after oversampling...")
    analyze_class_imbalance()
    
    # Step 6: Preprocess images
    preprocess_images()
    
    # Step 7: Stratified dataset split
    if not stratified_split_dataset():
        print("❌ Failed to split dataset!")
        return
    
    # Step 8: Create balanced YOLO configuration
    config_path = create_weighted_dataset_config()
    
    # Step 9: Setup training with class balancing
    train_params = setup_training_with_class_balancing()
    
    # Step 10: Create evaluation plots
    create_evaluation_plots()
    
    print("\n🔥 Starting Class-Balanced Training...")
    
    try:
        # Load YOLOv8n model
        model = YOLO('yolov8n.pt')
        
        # Train the model with balanced parameters
        results = model.train(
            data=config_path,
            **train_params
        )
        
        print("✅ Class-balanced training completed successfully!")
        
        # Step 11: Enhanced evaluation
        print("\n📊 Evaluating model with class balance metrics...")
        metrics = model.val()
        balanced_metrics = calculate_balanced_metrics(model)
        
        # Print per-class performance
        print("\n📈 Per-Class Performance Summary:")
        print("-" * 60)
        for class_name, info in balanced_metrics.items():
            status = "MINORITY" if info['is_minority'] else "MAJORITY"
            print(f"{class_name:15} | Samples: {info['sample_count']:4d} | Weight: {info['class_weight']:.3f} | {status}")
        
        # Step 12: Export model
        print("\n💾 Exporting balanced model...")
        try:
            export_path = model.export(format='onnx')
            print(f"✅ Model exported to: {export_path}")
        except Exception as e:
            print(f"⚠️ Export failed: {e}")
        
        # Step 13: Create comprehensive visualizations
        print("\n📊 Creating training visualizations...")
        create_training_plots_enhanced()
        
        # Step 14: Test model performance
        print("\n🧪 Testing balanced model...")
        test_model_with_class_analysis()
        
        return model, results
        
    except Exception as e:
        print(f"❌ Training failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return None, None

def create_training_plots_enhanced():
    """Create enhanced training visualization plots"""
    try:
        results_dir = "/content/runs/bubble_detection_balanced"
        if os.path.exists(results_dir):
            runs = [d for d in os.listdir(results_dir) if os.path.isdir(os.path.join(results_dir, d))]
            if runs:
                latest_run = max(runs, key=lambda x: os.path.getctime(os.path.join(results_dir, x)))
                results_path = os.path.join(results_dir, latest_run)
                
                print(f"📊 Enhanced results saved in: {results_path}")
                
                # Display training plots
                plots = ['results.png', 'confusion_matrix.png', 'F1_curve.png', 'PR_curve.png']
                
                fig, axes = plt.subplots(2, 2, figsize=(20, 16))
                axes = axes.flatten()
                
                for i, plot in enumerate(plots):
                    plot_path = os.path.join(results_path, plot)
                    if os.path.exists(plot_path) and i < len(axes):
                        img = plt.imread(plot_path)
                        axes[i].imshow(img)
                        axes[i].axis('off')
                        axes[i].set_title(f'{plot.replace("_", " ").replace(".png", "").title()}', fontsize=14)
                        print(f"✅ {plot} created")
                
                plt.tight_layout()
                plt.savefig('/content/training_results_enhanced.png', dpi=300, bbox_inches='tight')
                plt.show()
                
    except Exception as e:
        print(f"Warning: Could not create enhanced plots - {e}")

def test_model_with_class_analysis(model_path=None):
    """Test model with detailed class-wise analysis"""
    
    if model_path is None:
        model_path = "/content/runs/bubble_detection_balanced/train/weights/best.pt"
        if not os.path.exists(model_path):
            # Find the actual model path
            base_dir = "/content/runs/bubble_detection_balanced"
            if os.path.exists(base_dir):
                runs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]
                if runs:
                    latest_run = max(runs, key=lambda x: os.path.getctime(os.path.join(base_dir, x)))
                    model_path = os.path.join(base_dir, latest_run, "weights", "best.pt")
    
    if not os.path.exists(model_path):
        print(f"❌ Model not found: {model_path}")
        return
    
    print(f"🧪 Testing class-balanced model: {model_path}")
    
    # Load trained model
    model = YOLO(model_path)
    classes = model.names
    
    # Test on validation/test set
    test_dir = "/content/dataset/images/test"
    val_dir = "/content/dataset/images/val"
    
    test_directory = test_dir if os.path.exists(test_dir) else val_dir
    
    if not os.path.exists(test_directory):
        print("❌ No test directory found!")
        return
    
    test_images = [f for f in os.listdir(test_directory) 
                  if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    
    if not test_images:
        print("❌ No test images found!")
        return
    
    # Class-wise detection statistics
    class_detections = {cls: 0 for cls in classes.values()}
    total_detections = 0
    
    print(f"\n🔍 Testing on {len(test_images)} images...")
    
    # Test on sample images
    for i, img_file in enumerate(test_images[:5]):  # Test first 5 images
        img_path = os.path.join(test_directory, img_file)
        
        print(f"\n📷 Testing: {img_file}")
        
        # Run inference with balanced confidence thresholds
        results = model(img_path, conf=0.2, iou=0.4)  # Lower conf for minority classes
        
        # Analyze results
        for r in results:
            if len(r.boxes) > 0:
                print(f"   Detected {len(r.boxes)} objects:")
                for j, box in enumerate(r.boxes):
                    conf = box.conf[0].item()
                    cls_id = int(box.cls[0].item())
                    class_name = classes[cls_id]
                    
                    # Check if this is a minority class detection
                    is_minority = class_name in minority_classes
                    status = " (MINORITY)" if is_minority else ""
                    
                    print(f"     {j+1}. {class_name}: {conf:.3f}{status}")
                    
                    class_detections[class_name] += 1
                    total_detections += 1
            else:
                print("   No objects detected")
            
            # Save annotated image
            annotated = r.plot()
            output_path = f"/content/test_balanced_result_{i+1}.jpg"
            cv2.imwrite(output_path, annotated)
            print(f"   Result saved: {output_path}")
    
    # Print detection summary
    print(f"\n📊 DETECTION SUMMARY:")
    print("-" * 50)
    print(f"Total detections: {total_detections}")
    
    for class_name, count in class_detections.items():
        percentage = (count / total_detections * 100) if total_detections > 0 else 0
        is_minority = class_name in minority_classes
        status = "MINORITY" if is_minority else "MAJORITY"
        print(f"{class_name:15} | Detected: {count:3d} | {percentage:5.1f}% | {status}")
    
    return model

# ==========================================
# 12. EXECUTION
# ==========================================

if __name__ == "__main__":
    # Run the complete pipeline with class imbalance handling
    print("🎯 Initializing Class-Balanced YOLOv8 Training Pipeline...")
    
    model, results = main()
    
    if model is not None:
        print("\n🎉 Class-Balanced Pipeline completed successfully!")
        print("\n📁 Output files:")
        print("   - Balanced model: /content/runs/bubble_detection_balanced/train*/weights/best.pt")
        print("   - Class analysis: /content/class_balance_analysis.png")
        print("   - Training plots: /content/training_results_enhanced.png")
        print("   - Test results: /content/test_balanced_result_*.jpg")
        
        print("\n🎯 Class Balancing Techniques Applied:")
        if minority_classes:
            print("   ✅ Oversampling augmentation for minority classes")
            print("   ✅ Focal loss for classification")
            print("   ✅ Stratified data splitting")
            print("   ✅ Class-weighted loss functions")
            print("   ✅ Enhanced augmentation for minority classes")
            print("   ✅ Adjusted training hyperparameters")
            print(f"   📊 Minority classes handled: {minority_classes}")
        else:
            print("   ✅ Dataset is balanced - standard training applied")
        
        print("\n🔧 Usage example:")
        print("```python")
        print("from ultralytics import YOLO")
        print("# Load the class-balanced model")
        print("model = YOLO('/content/runs/bubble_detection_balanced/train*/weights/best.pt')")
        print("# Use lower confidence threshold for minority classes")
        print("results = model('path/to/image.jpg', conf=0.2)")
        print("```")
        
        print(f"\n📈 Final Class Distribution:")
        for cls, info in class_distribution.items():
            status = "MINORITY" if cls in minority_classes else "MAJORITY"
            print(f"   {cls}: {info['count']} samples ({info['percentage']:.1f}%) - {status}")
    
    else:
        print("\n❌ Class-balanced training failed. Please check your data and try again.")
        print("\n🔧 Troubleshooting tips:")
        print("   - Ensure images and labels are properly matched")
        print("   - Check annotation format (YOLO format required)")
        print("   - Verify classes.txt contains correct class names")
        print("   - Make sure you have sufficient GPU memory")

# Run the pipeline
print("🚀 Starting execution...")
main()