import serial
import serial.tools.list_ports
import time
import sys

def list_available_ports():
    """List all available serial ports"""
    print("🔍 Scanning for available COM ports...")
    ports = serial.tools.list_ports.comports()
    
    if not ports:
        print("❌ No COM ports found!")
        return []
    
    print(f"✅ Found {len(ports)} COM port(s):")
    for i, port in enumerate(ports, 1):
        print(f"  {i}. {port.device} - {port.description}")
        if "USB" in port.description or "ESP32" in port.description or "CH340" in port.description or "CP210" in port.description:
            print(f"     👆 This looks like an ESP32/Arduino device!")
    
    return [port.device for port in ports]

def test_port_connection(port, baud_rates=[115200, 9600, 57600]):
    """Test connection to a specific port with different baud rates"""
    print(f"\n🔧 Testing connection to {port}...")
    
    for baud_rate in baud_rates:
        print(f"  Testing baud rate: {baud_rate}")
        try:
            # Try to open serial connection
            ser = serial.Serial(
                port=port,
                baudrate=baud_rate,
                timeout=3,
                write_timeout=3
            )
            
            print(f"    ✅ Port opened successfully")
            time.sleep(2)  # Wait for ESP32 reset
            
            # Try to send PING command
            print(f"    📤 Sending PING command...")
            ser.write(b"PING\n")
            time.sleep(0.5)
            
            # Try to read response
            if ser.in_waiting:
                response = ser.readline().decode('utf-8', errors='ignore').strip()
                print(f"    📥 Response: '{response}'")
                
                if "PONG" in response:
                    print(f"    🎉 ESP32 responded correctly!")
                    ser.close()
                    return True, baud_rate
                else:
                    print(f"    ⚠️  Got response but not PONG")
            else:
                print(f"    ⚠️  No response received")
            
            # Try reading any available data
            print(f"    📖 Reading available data for 3 seconds...")
            start_time = time.time()
            while time.time() - start_time < 3:
                if ser.in_waiting:
                    data = ser.readline().decode('utf-8', errors='ignore').strip()
                    if data:
                        print(f"    📥 Data: '{data}'")
                time.sleep(0.1)
            
            ser.close()
            print(f"    ❌ No valid response at {baud_rate}")
            
        except serial.SerialException as e:
            print(f"    ❌ Serial error: {e}")
        except Exception as e:
            print(f"    ❌ Error: {e}")
        
        time.sleep(1)
    
    return False, None

def main():
    print("🔧 ESP32 Connection Diagnostic Tool")
    print("=" * 50)
    
    # Step 1: List available ports
    available_ports = list_available_ports()
    
    if not available_ports:
        print("\n💡 Troubleshooting tips:")
        print("  1. Make sure ESP32 is connected via USB")
        print("  2. Check if USB cable supports data transfer (not just charging)")
        print("  3. Install ESP32 drivers (CH340/CP210x)")
        print("  4. Try different USB port")
        print("  5. Check Device Manager for unknown devices")
        return
    
    # Step 2: Test each port
    print(f"\n🧪 Testing connections...")
    
    working_ports = []
    
    for port in available_ports:
        success, baud_rate = test_port_connection(port)
        if success:
            working_ports.append((port, baud_rate))
            print(f"✅ {port} is working with baud rate {baud_rate}")
        else:
            print(f"❌ {port} is not responding")
    
    # Step 3: Results and recommendations
    print(f"\n📊 Results:")
    print("=" * 30)
    
    if working_ports:
        print(f"✅ Found {len(working_ports)} working port(s):")
        for port, baud_rate in working_ports:
            print(f"  📍 {port} at {baud_rate} baud")
        
        print(f"\n💡 Update your configuration:")
        recommended_port, recommended_baud = working_ports[0]
        print(f"  esp32_port = '{recommended_port}'")
        print(f"  baud_rate = {recommended_baud}")
        
    else:
        print(f"❌ No working ports found!")
        print(f"\n🔧 Troubleshooting steps:")
        print(f"  1. Check physical connections")
        print(f"  2. Verify ESP32 code is uploaded")
        print(f"  3. Try pressing ESP32 reset button")
        print(f"  4. Use Arduino IDE Serial Monitor to test manually")
        print(f"  5. Check if another program is using the port")
        print(f"  6. Install/update ESP32 drivers")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n🛑 Diagnostic interrupted by user")
    except Exception as e:
        print(f"\n❌ Diagnostic error: {e}")