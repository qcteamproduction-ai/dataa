import cv2

def check_cameras(max_index=10):
    print("Checking available cameras...")
    for i in range(max_index):
        cap = cv2.VideoCapture(i, cv2.CAP_ANY)
        if cap.isOpened():
            print(f"Camera index {i} is available")
            ret, frame = cap.read()
            if ret:
                print(f"Successfully read frame from camera index {i}")
            cap.release()
        else:
            print(f"Camera index {i} is NOT available")

if __name__ == "__main__":
    check_cameras()