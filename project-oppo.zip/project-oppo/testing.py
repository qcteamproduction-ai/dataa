import cv2
from ultralytics import YOLO

# Load YOLOv8 model
model = YOLO('oppo-yolo8n-new.pt')

# Initialize camera with index 1 and CAP_DSHOW
cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)

if not cap.isOpened():
    print("Error: Could not open camera 1")
    exit()

# Print camera properties for debugging
print(f"Camera 1 - Width: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}, Height: {cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}, FPS: {cap.get(cv2.CAP_PROP_FPS)}")

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame from camera 1")
            break

        # Perform YOLO detection
        results = model(frame, show=True)
        cv2.imshow('Camera 1 - YOLOv8', results[0].plot())

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    cap.release()
    cv2.destroyAllWindows()